window.Pages = window.Pages || {};

window.Pages.MetaProductLookup = function MetaProductLookup() {
  const { useState, useEffect, useCallback } = React;
  const Modal = window.Components.Modal;

  const [items, setItems] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showCreate, setShowCreate] = useState(false);

  const load = useCallback(async (q) => {
    setLoading(true);
    setError(null);
    try {
      const data = await Api.listMetaProducts(q);
      setItems(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load('');
  }, [load]);

  useEffect(() => {
    const t = setTimeout(() => load(search), 300);
    return () => clearTimeout(t);
  }, [search, load]);

  return (
    <div className="page">
      <div className="page-header">
        <h1>Meta-Products</h1>
        <button className="btn btn-primary" onClick={() => setShowCreate(true)}>
          + New Meta-Product
        </button>
      </div>

      <input
        className="input search-input"
        placeholder="Search by name, vendor, or product line..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      {error && <div className="alert alert-error">{error}</div>}
      {loading ? (
        <div className="empty-state">Loading...</div>
      ) : items.length === 0 ? (
        <div className="empty-state">No meta-products found. Create one to get started.</div>
      ) : (
        <table className="data-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Vendor</th>
              <th>Product Line</th>
              <th>Last Updated</th>
            </tr>
          </thead>
          <tbody>
            {items.map((mp) => (
              <tr key={mp.id} className="clickable-row" onClick={() => Router.navigate('/meta-products/' + mp.id)}>
                <td>{mp.name}</td>
                <td>{mp.vendor || '—'}</td>
                <td>{mp.product_line || '—'}</td>
                <td>{new Date(mp.updated_at).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {showCreate && (
        <CreateMetaProductModal
          onClose={() => setShowCreate(false)}
          onCreated={(mp) => {
            setShowCreate(false);
            Router.navigate('/meta-products/' + mp.id);
          }}
        />
      )}
    </div>
  );
};

function CreateMetaProductModal({ onClose, onCreated }) {
  const { useState } = React;
  const Modal = window.Components.Modal;
  const [form, setForm] = useState({ name: '', vendor: '', product_line: '' });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const update = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) {
      setError('Name is required');
      return;
    }
    setSaving(true);
    setError(null);
    try {
      const mp = await Api.createMetaProduct(form);
      onCreated(mp);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal title="New Meta-Product" onClose={onClose}>
      <form onSubmit={submit} className="form">
        {error && <div className="alert alert-error">{error}</div>}
        <label className="form-field">
          <span>Name *</span>
          <input className="input" value={form.name} onChange={update('name')} autoFocus />
        </label>
        <label className="form-field">
          <span>Vendor</span>
          <input className="input" value={form.vendor} onChange={update('vendor')} />
        </label>
        <label className="form-field">
          <span>Product Line</span>
          <input className="input" value={form.product_line} onChange={update('product_line')} />
        </label>
        <div className="form-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary" disabled={saving}>
            {saving ? 'Creating...' : 'Create'}
          </button>
        </div>
      </form>
    </Modal>
  );
}
