window.Pages = window.Pages || {};

window.Pages.MetaProductOutput = function MetaProductOutput({ metaProduct }) {
  const { useState, useEffect, useCallback } = React;

  const [features, setFeatures] = useState([]);
  const [constraints, setConstraints] = useState([]);
  const [lists, setLists] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [downloading, setDownloading] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [f, c, l] = await Promise.all([
        Api.listFeatures(metaProduct.id),
        Api.listConstraints(metaProduct.id),
        Api.listConstraintLists(metaProduct.id)
      ]);
      setFeatures(f);
      setConstraints(c);
      setLists(l);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [metaProduct.id]);

  useEffect(() => {
    load();
  }, [load]);

  const totalOptions = features.reduce((sum, f) => sum + ((f.options && f.options.length) || 0), 0);
  const featuresMissingOptions = features.filter(
    (f) => (f.data_type === 'choice' || f.data_type === 'boolean') && !(f.options && f.options.length)
  );
  const totalListRows = lists.reduce((sum, l) => sum + (l.row_count || 0), 0);

  const downloadOptions = async () => {
    setDownloading('options');
    setError(null);
    try {
      await ExportXlsx.downloadOptionsFile(metaProduct, features);
    } catch (err) {
      setError(err.message);
    } finally {
      setDownloading(null);
    }
  };

  const downloadCompatibility = async () => {
    setDownloading('compatibility');
    setError(null);
    try {
      // Fetch full row data (with parsed rows) for every uploaded list
      const fullLists = await Promise.all(lists.map((l) => Api.getConstraintListWithData(l.id)));
      await ExportXlsx.downloadCompatibilityFile(metaProduct, constraints, fullLists);
    } catch (err) {
      setError(err.message);
    } finally {
      setDownloading(null);
    }
  };

  return (
    <div>
      <div className="section-header">
        <h2>Review & Download</h2>
      </div>

      {error && <div className="alert alert-error">{error}</div>}
      {loading ? (
        <div className="empty-state">Loading...</div>
      ) : (
        <>
          <div className="summary-grid">
            <SummaryStat label="Features" value={features.length} />
            <SummaryStat label="Total Options" value={totalOptions} />
            <SummaryStat label="Manual Constraints" value={constraints.length} />
            <SummaryStat label="Uploaded List Rows" value={totalListRows} />
          </div>

          {featuresMissingOptions.length > 0 && (
            <div className="alert alert-warning">
              {featuresMissingOptions.length} feature(s) have no options mapped yet: {featuresMissingOptions.map((f) => f.name).join(', ')}.
              Consider completing Option Mapping before exporting.
            </div>
          )}

          <div className="download-section">
            <div className="download-card">
              <h3>Option File</h3>
              <p>Every feature and its mapped options/choices, ready for import downstream.</p>
              <button className="btn btn-primary" onClick={downloadOptions} disabled={downloading === 'options' || features.length === 0}>
                {downloading === 'options' ? 'Preparing...' : 'Download Options.xlsx'}
              </button>
            </div>
            <div className="download-card">
              <h3>Compatibility File</h3>
              <p>All manually-added constraints plus every row from uploaded white/black list files, merged into one workbook.</p>
              <button className="btn btn-primary" onClick={downloadCompatibility} disabled={downloading === 'compatibility'}>
                {downloading === 'compatibility' ? 'Preparing...' : 'Download Compatibility.xlsx'}
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

function SummaryStat({ label, value }) {
  return (
    <div className="summary-stat">
      <div className="summary-stat-value">{value}</div>
      <div className="summary-stat-label">{label}</div>
    </div>
  );
}
