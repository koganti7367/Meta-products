window.Pages = window.Pages || {};

window.Pages.FeatureManagement = function FeatureManagement({ metaProduct }) {
  const { useState, useEffect, useCallback } = React;
  const FeatureDetailModal = window.Components.FeatureDetailModal;
  const AddConstraintModal = window.Components.AddConstraintModal;

  const DATA_TYPE_LABELS = { choice: 'Choice', boolean: 'Boolean', number: 'Number', text: 'Text' };

  const [features, setFeatures] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [editingFeature, setEditingFeature] = useState(undefined); // undefined=closed, null=create, obj=edit
  const [constraintFrom, setConstraintFrom] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await Api.listFeatures(metaProduct.id);
      setFeatures(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [metaProduct.id]);

  useEffect(() => {
    load();
  }, [load]);

  return (
    <div>
      <div className="section-header">
        <h2>Features</h2>
        <button className="btn btn-primary" onClick={() => setEditingFeature(null)}>
          + Add Feature
        </button>
      </div>

      {error && <div className="alert alert-error">{error}</div>}
      {loading ? (
        <div className="empty-state">Loading...</div>
      ) : features.length === 0 ? (
        <div className="empty-state">No features yet. Add the first one to get started.</div>
      ) : (
        <table className="data-table">
          <thead>
            <tr>
              <th>Feature</th>
              <th>Type</th>
              <th>Required</th>
              <th>Options</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {features.map((f) => (
              <tr key={f.id}>
                <td className="clickable-cell" onClick={() => setEditingFeature(f)}>
                  <strong>{f.name}</strong>
                  {f.description && <div className="cell-subtext">{f.description}</div>}
                </td>
                <td>{DATA_TYPE_LABELS[f.data_type] || f.data_type}</td>
                <td>{f.is_required ? 'Yes' : 'No'}</td>
                <td>{f.options && f.options.length ? f.options.length + ' option(s)' : '—'}</td>
                <td className="row-actions">
                  <button className="btn btn-small" onClick={() => setConstraintFrom(f)}>
                    + Constraint
                  </button>
                  <button
                    className="btn btn-small btn-secondary"
                    onClick={() => Router.navigate('/meta-products/' + metaProduct.id + '/constraints?feature=' + f.id)}
                  >
                    View Constraints
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {editingFeature !== undefined && (
        <FeatureDetailModal
          metaProduct={metaProduct}
          feature={editingFeature}
          onClose={() => setEditingFeature(undefined)}
          onSaved={() => {
            setEditingFeature(undefined);
            load();
          }}
          onDeleted={() => {
            setEditingFeature(undefined);
            load();
          }}
        />
      )}

      {constraintFrom && (
        <AddConstraintModal
          metaProduct={metaProduct}
          features={features}
          fromFeature={constraintFrom}
          onClose={() => setConstraintFrom(null)}
          onSaved={() => setConstraintFrom(null)}
        />
      )}
    </div>
  );
};
