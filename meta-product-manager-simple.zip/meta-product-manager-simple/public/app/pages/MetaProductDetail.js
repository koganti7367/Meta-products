window.Pages = window.Pages || {};

window.Pages.MetaProductDetail = function MetaProductDetail({ id, tab, query }) {
  const { useState, useEffect } = React;
  const [metaProduct, setMetaProduct] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    setMetaProduct(null);
    Api.getMetaProduct(id).then(setMetaProduct).catch((err) => setError(err.message));
  }, [id]);

  if (error) return <div className="alert alert-error">{error}</div>;
  if (!metaProduct) return <div className="empty-state">Loading...</div>;

  const base = '/meta-products/' + id;

  const TABS = [
    { key: 'features', label: 'Features' },
    { key: 'constraints', label: 'Constraints' },
    { key: 'lists', label: 'White/Black Lists' },
    { key: 'option-mapping', label: 'Option Mapping' },
    { key: 'output', label: 'Review & Download' }
  ];

  let TabComponent = null;
  switch (tab) {
    case 'constraints':
      TabComponent = <window.Pages.ConstraintsView metaProduct={metaProduct} query={query} />;
      break;
    case 'lists':
      TabComponent = <window.Pages.ListFileManager metaProduct={metaProduct} />;
      break;
    case 'option-mapping':
      TabComponent = <window.Pages.OptionMapping metaProduct={metaProduct} />;
      break;
    case 'output':
      TabComponent = <window.Pages.MetaProductOutput metaProduct={metaProduct} />;
      break;
    case 'features':
    default:
      TabComponent = <window.Pages.FeatureManagement metaProduct={metaProduct} />;
      break;
  }

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>{metaProduct.name}</h1>
          <p className="subtitle">
            {metaProduct.vendor || 'No vendor'} · {metaProduct.product_line || 'No product line'}
          </p>
        </div>
      </div>

      <nav className="tab-nav">
        {TABS.map((t) => (
          <a key={t.key} href={'#' + base + '/' + t.key} className={'tab-link' + (tab === t.key ? ' active' : '')}>
            {t.label}
          </a>
        ))}
      </nav>

      <div className="tab-content">{TabComponent}</div>
    </div>
  );
};
