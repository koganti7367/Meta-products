window.Pages = window.Pages || {};

window.Pages.ListFileManager = function ListFileManager({ metaProduct }) {
  const { useState, useEffect, useCallback, useRef } = React;

  const [lists, setLists] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [uploadType, setUploadType] = useState('whitelist');
  const [uploadName, setUploadName] = useState('');
  const fileInputRef = useRef(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await Api.listConstraintLists(metaProduct.id);
      setLists(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [metaProduct.id]);

  useEffect(() => {
    load();
  }, [load]);

  const handleFileChange = async (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    setUploading(true);
    setError(null);
    try {
      const rows = await ExportXlsx.parseListFile(file);
      await Api.uploadConstraintList({
        meta_product_id: metaProduct.id,
        name: uploadName.trim() || file.name.replace(/\.xlsx?$/i, ''),
        type: uploadType,
        original_filename: file.name,
        rows
      });
      setUploadName('');
      if (fileInputRef.current) fileInputRef.current.value = '';
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this list?')) return;
    try {
      await Api.deleteConstraintList(id);
      load();
    } catch (err) {
      setError(err.message);
    }
  };

  const handleDownload = async (list) => {
    try {
      const full = await Api.getConstraintListWithData(list.id);
      ExportXlsx.downloadListFile(full);
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div>
      <div className="section-header">
        <h2>White / Black List Files</h2>
      </div>

      <p className="hint">
        Upload an Excel file with columns: <code>From Feature</code>, <code>From Option</code>,{' '}
        <code>To Feature</code>, <code>To Option</code>, <code>Notes</code> (optional). These rows are
        combined with manually-added constraints in the final Compatibility export.
      </p>

      <div className="upload-bar">
        <label className="form-field inline">
          <span>List Name</span>
          <input
            className="input"
            placeholder="(defaults to filename)"
            value={uploadName}
            onChange={(e) => setUploadName(e.target.value)}
          />
        </label>
        <label className="form-field inline">
          <span>Type</span>
          <select className="input" value={uploadType} onChange={(e) => setUploadType(e.target.value)}>
            <option value="whitelist">Whitelist</option>
            <option value="blacklist">Blacklist</option>
          </select>
        </label>
        <label className="btn btn-primary file-upload-btn">
          {uploading ? 'Uploading...' : 'Upload .xlsx'}
          <input ref={fileInputRef} type="file" accept=".xlsx,.xls" onChange={handleFileChange} disabled={uploading} hidden />
        </label>
      </div>

      {error && <div className="alert alert-error">{error}</div>}
      {loading ? (
        <div className="empty-state">Loading...</div>
      ) : lists.length === 0 ? (
        <div className="empty-state">No lists uploaded yet.</div>
      ) : (
        <table className="data-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Type</th>
              <th>Rows</th>
              <th>Uploaded</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {lists.map((l) => (
              <tr key={l.id}>
                <td>{l.name}</td>
                <td>
                  <span className={'badge badge-' + l.type}>{l.type}</span>
                </td>
                <td>{l.row_count}</td>
                <td>{new Date(l.uploaded_at).toLocaleString()}</td>
                <td className="row-actions">
                  <button className="btn btn-small btn-secondary" onClick={() => handleDownload(l)}>
                    Download
                  </button>
                  <button className="btn btn-small btn-danger" onClick={() => handleDelete(l.id)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};
