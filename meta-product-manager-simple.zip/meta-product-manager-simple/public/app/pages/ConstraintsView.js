window.Pages = window.Pages || {};

window.Pages.ConstraintsView = function ConstraintsView({ metaProduct, query }) {
  const { useState, useEffect, useCallback } = React;

  const featureId = query.get('feature') || '';
  const direction = query.get('direction') || 'either';

  const [features, setFeatures] = useState([]);
  const [constraints, setConstraints] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    Api.listFeatures(metaProduct.id).then(setFeatures).catch((err) => setError(err.message));
  }, [metaProduct.id]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await Api.listConstraints(metaProduct.id, featureId || undefined, featureId ? direction : undefined);
      setConstraints(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [metaProduct.id, featureId, direction]);

  useEffect(() => {
    load();
  }, [load]);

  const base = '/meta-products/' + metaProduct.id + '/constraints';

  const setFeatureFilter = (value) => {
    const params = new URLSearchParams(query);
    if (value) params.set('feature', value);
    else {
      params.delete('feature');
      params.delete('direction');
    }
    const qs = params.toString();
    Router.navigate(base + (qs ? '?' + qs : ''));
  };

  const setDirectionFilter = (value) => {
    const params = new URLSearchParams(query);
    params.set('direction', value);
    Router.navigate(base + '?' + params.toString());
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this constraint?')) return;
    try {
      await Api.deleteConstraint(id);
      load();
    } catch (err) {
      setError(err.message);
    }
  };

  const optionLabel = (opt) => (opt ? opt.label : '(any)');

  return (
    <div>
      <div className="section-header">
        <h2>Constraints</h2>
      </div>

      <div className="filter-bar">
        <label className="form-field inline">
          <span>Feature</span>
          <select className="input" value={featureId} onChange={(e) => setFeatureFilter(e.target.value)}>
            <option value="">All features</option>
            {features.map((f) => (
              <option key={f.id} value={f.id}>
                {f.name}
              </option>
            ))}
          </select>
        </label>

        {featureId && (
          <label className="form-field inline">
            <span>Direction</span>
            <select className="input" value={direction} onChange={(e) => setDirectionFilter(e.target.value)}>
              <option value="either">To, from, or including</option>
              <option value="from">From this feature</option>
              <option value="to">To this feature</option>
            </select>
          </label>
        )}
      </div>

      {error && <div className="alert alert-error">{error}</div>}
      {loading ? (
        <div className="empty-state">Loading...</div>
      ) : constraints.length === 0 ? (
        <div className="empty-state">No constraints match this filter.</div>
      ) : (
        <table className="data-table">
          <thead>
            <tr>
              <th>Type</th>
              <th>From</th>
              <th>To</th>
              <th>Notes</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {constraints.map((c) => (
              <tr key={c.id}>
                <td>
                  <span className={'badge badge-' + c.type}>{c.type}</span>
                </td>
                <td>
                  {c.from_feature ? c.from_feature.name : ''} — {optionLabel(c.from_option)}
                </td>
                <td>
                  {c.to_feature ? c.to_feature.name : ''} — {optionLabel(c.to_option)}
                </td>
                <td>{c.description || '—'}</td>
                <td className="row-actions">
                  <button className="btn btn-small btn-danger" onClick={() => handleDelete(c.id)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};
