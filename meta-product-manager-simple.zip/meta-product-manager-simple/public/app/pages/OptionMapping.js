window.Pages = window.Pages || {};

window.Pages.OptionMapping = function OptionMapping({ metaProduct }) {
  const { useState, useEffect, useCallback } = React;

  const [features, setFeatures] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [dirtyIds, setDirtyIds] = useState(new Set());
  const [savingId, setSavingId] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await Api.listFeatures(metaProduct.id);
      setFeatures(data.filter((f) => f.data_type === 'choice' || f.data_type === 'boolean'));
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [metaProduct.id]);

  useEffect(() => {
    load();
  }, [load]);

  const markDirty = (id) =>
    setDirtyIds((prev) => {
      const next = new Set(prev);
      next.add(id);
      return next;
    });

  const applySuggestion = (featureId) => {
    setFeatures((prev) =>
      prev.map((f) => {
        if (f.id !== featureId) return f;
        if (f.options && f.options.length) {
          const proceed = window.confirm('This feature already has options. Replace them with suggested options?');
          if (!proceed) return f;
        }
        const suggested = suggestOptionsFor(f).map((o, idx) => ({
          id: 'temp-' + featureId + '-' + idx,
          ...o,
          is_default: idx === 0,
          sort_order: idx
        }));
        return { ...f, options: suggested };
      })
    );
    markDirty(featureId);
  };

  const updateOptionField = (featureId, optIdx, field, value) => {
    setFeatures((prev) =>
      prev.map((f) => {
        if (f.id !== featureId) return f;
        const options = [...f.options];
        options[optIdx] = { ...options[optIdx], [field]: value };
        return { ...f, options };
      })
    );
    markDirty(featureId);
  };

  const addBlankOption = (featureId) => {
    setFeatures((prev) =>
      prev.map((f) => {
        if (f.id !== featureId) return f;
        const options = [...(f.options || []), { id: 'temp-' + featureId + '-' + Date.now(), value: '', label: '', is_default: false }];
        return { ...f, options };
      })
    );
    markDirty(featureId);
  };

  const removeOption = (featureId, optIdx) => {
    setFeatures((prev) =>
      prev.map((f) => {
        if (f.id !== featureId) return f;
        return { ...f, options: f.options.filter((_, i) => i !== optIdx) };
      })
    );
    markDirty(featureId);
  };

  const saveFeature = async (feature) => {
    setSavingId(feature.id);
    setError(null);
    try {
      const cleanOptions = (feature.options || []).map((o, idx) => ({
        value: o.value,
        label: o.label,
        is_default: !!o.is_default,
        sort_order: idx
      }));
      await Api.updateFeature(feature.id, {
        name: feature.name,
        description: feature.description,
        data_type: feature.data_type,
        is_required: feature.is_required,
        options: cleanOptions
      });
      setDirtyIds((prev) => {
        const next = new Set(prev);
        next.delete(feature.id);
        return next;
      });
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSavingId(null);
    }
  };

  return (
    <div>
      <div className="section-header">
        <h2>Map Features to Options / Choices</h2>
      </div>
      <p className="hint">
        Choice and Boolean features can be mapped to their selectable options here. Use <strong>Auto-suggest</strong> to
        semi-populate common option sets, then adjust as needed.
      </p>

      {error && <div className="alert alert-error">{error}</div>}
      {loading ? (
        <div className="empty-state">Loading...</div>
      ) : features.length === 0 ? (
        <div className="empty-state">No choice/boolean features yet. Add features first from the Features tab.</div>
      ) : (
        features.map((f) => (
          <div key={f.id} className="mapping-card">
            <div className="mapping-card-header">
              <div>
                <strong>{f.name}</strong> <span className="tag">{f.data_type}</span>
              </div>
              <div className="row-actions">
                <button className="btn btn-small" onClick={() => applySuggestion(f.id)}>
                  ✨ Auto-suggest
                </button>
                <button className="btn btn-small btn-secondary" onClick={() => addBlankOption(f.id)}>
                  + Add Option
                </button>
                <button
                  className="btn btn-small btn-primary"
                  disabled={!dirtyIds.has(f.id) || savingId === f.id}
                  onClick={() => saveFeature(f)}
                >
                  {savingId === f.id ? 'Saving...' : 'Save'}
                </button>
              </div>
            </div>

            {!f.options || f.options.length === 0 ? (
              <p className="hint">No options mapped yet.</p>
            ) : (
              <div className="option-row-list">
                {f.options.map((o, idx) => (
                  <div key={o.id} className="option-row">
                    <input className="input" placeholder="Value" value={o.value} onChange={(e) => updateOptionField(f.id, idx, 'value', e.target.value)} />
                    <input className="input" placeholder="Label" value={o.label} onChange={(e) => updateOptionField(f.id, idx, 'label', e.target.value)} />
                    <label className="checkbox-field small">
                      <input type="checkbox" checked={!!o.is_default} onChange={(e) => updateOptionField(f.id, idx, 'is_default', e.target.checked)} />
                      <span>Default</span>
                    </label>
                    <button className="icon-button" onClick={() => removeOption(f.id, idx)} aria-label="Remove option">
                      ✕
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))
      )}
    </div>
  );
};
