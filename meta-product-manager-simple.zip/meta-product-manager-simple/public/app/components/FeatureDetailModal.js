window.Components = window.Components || {};

window.Components.FeatureDetailModal = function FeatureDetailModal({ metaProduct, feature, onClose, onSaved, onDeleted }) {
  const { useState } = React;
  const Modal = window.Components.Modal;

  const DATA_TYPES = [
    { value: 'choice', label: 'Choice (list of options)' },
    { value: 'boolean', label: 'Boolean (Yes/No)' },
    { value: 'number', label: 'Number' },
    { value: 'text', label: 'Free text' }
  ];

  const isEdit = !!feature;
  const [form, setForm] = useState({
    name: feature ? feature.name : '',
    description: feature ? feature.description || '' : '',
    data_type: feature ? feature.data_type : 'choice',
    is_required: feature ? !!feature.is_required : false
  });
  const [options, setOptions] = useState(
    ((feature && feature.options) || []).map((o) => ({ ...o }))
  );
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const update = (field) => (e) => {
    const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    setForm({ ...form, [field]: value });
  };

  let tempCounter = 0;
  const addOption = () => {
    setOptions([...options, { id: 'temp-' + Date.now() + '-' + tempCounter++, value: '', label: '', is_default: false }]);
  };

  const updateOption = (idx, field, value) => {
    const next = [...options];
    next[idx] = { ...next[idx], [field]: value };
    setOptions(next);
  };

  const removeOption = (idx) => setOptions(options.filter((_, i) => i !== idx));

  const submit = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) {
      setError('Feature name is required');
      return;
    }
    if (form.data_type === 'choice' && options.some((o) => !o.value.trim() || !o.label.trim())) {
      setError('All options need both a value and a label');
      return;
    }

    setSaving(true);
    setError(null);
    try {
      const cleanOptions = options.map((o, idx) => ({
        value: o.value,
        label: o.label,
        is_default: !!o.is_default,
        sort_order: idx
      }));

      let saved;
      if (isEdit) {
        saved = await Api.updateFeature(feature.id, { ...form, options: cleanOptions });
      } else {
        saved = await Api.createFeature({ ...form, meta_product_id: metaProduct.id });
        for (const opt of cleanOptions) {
          await Api.createFeatureOption({ ...opt, feature_id: saved.id });
        }
      }
      onSaved(saved);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm('Delete feature "' + feature.name + '"? This cannot be undone.')) return;
    setSaving(true);
    try {
      await Api.deleteFeature(feature.id);
      onDeleted(feature.id);
    } catch (err) {
      setError(err.message);
      setSaving(false);
    }
  };

  return (
    <Modal title={isEdit ? 'Edit Feature: ' + feature.name : 'Add Feature'} onClose={onClose} width={620}>
      <form onSubmit={submit} className="form">
        {error && <div className="alert alert-error">{error}</div>}

        <label className="form-field">
          <span>Feature Name *</span>
          <input className="input" value={form.name} onChange={update('name')} autoFocus />
        </label>

        <label className="form-field">
          <span>Description</span>
          <textarea className="input" rows={2} value={form.description} onChange={update('description')} />
        </label>

        <div className="form-row">
          <label className="form-field">
            <span>Data Type</span>
            <select className="input" value={form.data_type} onChange={update('data_type')}>
              {DATA_TYPES.map((t) => (
                <option key={t.value} value={t.value}>
                  {t.label}
                </option>
              ))}
            </select>
          </label>
          <label className="form-field checkbox-field">
            <input type="checkbox" checked={form.is_required} onChange={update('is_required')} />
            <span>Required</span>
          </label>
        </div>

        {form.data_type === 'choice' && (
          <div className="options-editor">
            <div className="options-editor-header">
              <span>Options / Choices</span>
              <button type="button" className="btn btn-small" onClick={addOption}>
                + Add Option
              </button>
            </div>
            {options.length === 0 && <p className="hint">No options yet. Add at least one.</p>}
            {options.map((opt, idx) => (
              <div key={opt.id} className="option-row">
                <input
                  className="input"
                  placeholder="Value (e.g. RED)"
                  value={opt.value}
                  onChange={(e) => updateOption(idx, 'value', e.target.value)}
                />
                <input
                  className="input"
                  placeholder="Label (e.g. Red)"
                  value={opt.label}
                  onChange={(e) => updateOption(idx, 'label', e.target.value)}
                />
                <label className="checkbox-field small">
                  <input
                    type="checkbox"
                    checked={!!opt.is_default}
                    onChange={(e) => updateOption(idx, 'is_default', e.target.checked)}
                  />
                  <span>Default</span>
                </label>
                <button type="button" className="icon-button" onClick={() => removeOption(idx)} aria-label="Remove option">
                  ✕
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="form-actions">
          {isEdit && (
            <button type="button" className="btn btn-danger" onClick={handleDelete} disabled={saving}>
              Delete
            </button>
          )}
          <div className="spacer" />
          <button type="button" className="btn btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary" disabled={saving}>
            {saving ? 'Saving...' : 'Save'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
