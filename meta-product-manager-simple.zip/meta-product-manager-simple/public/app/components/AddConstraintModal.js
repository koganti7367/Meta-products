window.Components = window.Components || {};

window.Components.AddConstraintModal = function AddConstraintModal({ metaProduct, features, fromFeature, onClose, onSaved }) {
  const { useState } = React;
  const Modal = window.Components.Modal;

  const [form, setForm] = useState({
    type: 'whitelist',
    from_feature_id: fromFeature.id,
    from_option_id: '',
    to_feature_id: '',
    to_option_id: '',
    description: ''
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const fromFeatureObj = features.find((f) => f.id === form.from_feature_id);
  const toFeatureObj = features.find((f) => f.id === form.to_feature_id);
  const otherFeatures = features.filter((f) => f.id !== form.from_feature_id);

  const update = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    if (!form.to_feature_id) {
      setError('Choose a target feature for the constraint');
      return;
    }
    setSaving(true);
    setError(null);
    try {
      const payload = {
        ...form,
        meta_product_id: metaProduct.id,
        from_option_id: form.from_option_id || null,
        to_option_id: form.to_option_id || null
      };
      const created = await Api.createConstraint(payload);
      onSaved(created);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal title={'Add Constraint from "' + fromFeature.name + '"'} onClose={onClose} width={560}>
      <form onSubmit={submit} className="form">
        {error && <div className="alert alert-error">{error}</div>}

        <label className="form-field">
          <span>Constraint Type *</span>
          <select className="input" value={form.type} onChange={update('type')}>
            <option value="whitelist">Whitelist (allows / requires)</option>
            <option value="blacklist">Blacklist (excludes)</option>
          </select>
        </label>

        <div className="constraint-grid">
          <div className="constraint-side">
            <h4>From</h4>
            <label className="form-field">
              <span>Feature</span>
              <input className="input" value={fromFeatureObj ? fromFeatureObj.name : ''} disabled />
            </label>
            <label className="form-field">
              <span>Option (optional — any if blank)</span>
              <select className="input" value={form.from_option_id} onChange={update('from_option_id')}>
                <option value="">(any option)</option>
                {((fromFeatureObj && fromFeatureObj.options) || []).map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.label}
                  </option>
                ))}
              </select>
            </label>
          </div>

          <div className="constraint-arrow">→</div>

          <div className="constraint-side">
            <h4>To</h4>
            <label className="form-field">
              <span>Feature *</span>
              <select className="input" value={form.to_feature_id} onChange={update('to_feature_id')}>
                <option value="">Select feature...</option>
                {otherFeatures.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="form-field">
              <span>Option (optional — any if blank)</span>
              <select className="input" value={form.to_option_id} onChange={update('to_option_id')} disabled={!toFeatureObj}>
                <option value="">(any option)</option>
                {((toFeatureObj && toFeatureObj.options) || []).map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.label}
                  </option>
                ))}
              </select>
            </label>
          </div>
        </div>

        <label className="form-field">
          <span>Description / Notes</span>
          <textarea className="input" rows={2} value={form.description} onChange={update('description')} />
        </label>

        <div className="form-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary" disabled={saving}>
            {saving ? 'Saving...' : 'Add Constraint'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
