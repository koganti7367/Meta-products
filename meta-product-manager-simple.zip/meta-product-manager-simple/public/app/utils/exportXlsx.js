// Builds and downloads the Option / Compatibility workbooks entirely in the
// browser using SheetJS (window.XLSX, loaded via CDN in index.html).
// No server-side xlsx dependency needed.
(function () {
  function slug(str) {
    return (str || 'meta-product')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
  }

  function downloadWorkbook(workbook, filename) {
    XLSX.writeFile(workbook, filename);
  }

  async function downloadOptionsFile(metaProduct, features) {
    const rows = [];
    for (const feature of features) {
      const options = feature.options || [];
      if (!options.length) {
        rows.push({
          Feature: feature.name,
          'Data Type': feature.data_type,
          Required: feature.is_required ? 'Yes' : 'No',
          'Option Value': '',
          'Option Label': '',
          Default: ''
        });
      }
      for (const opt of options) {
        rows.push({
          Feature: feature.name,
          'Data Type': feature.data_type,
          Required: feature.is_required ? 'Yes' : 'No',
          'Option Value': opt.value,
          'Option Label': opt.label,
          Default: opt.is_default ? 'Yes' : 'No'
        });
      }
    }
    const sheet = XLSX.utils.json_to_sheet(rows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, sheet, 'Options');
    downloadWorkbook(workbook, slug(metaProduct.name) + '-options.xlsx');
  }

  async function downloadCompatibilityFile(metaProduct, constraints, lists) {
    const optionLabel = (opt) => (opt ? opt.label || opt.value : '(any)');

    const rows = constraints.map((c) => ({
      Type: c.type,
      'From Feature': c.from_feature ? c.from_feature.name : '',
      'From Option': optionLabel(c.from_option),
      'To Feature': c.to_feature ? c.to_feature.name : '',
      'To Option': optionLabel(c.to_option),
      Source: 'Manual',
      Notes: c.description || ''
    }));

    for (const list of lists) {
      for (const row of list.data || []) {
        rows.push({
          Type: list.type,
          'From Feature': row.fromFeature,
          'From Option': row.fromOption,
          'To Feature': row.toFeature,
          'To Option': row.toOption,
          Source: 'Uploaded: ' + list.name,
          Notes: row.notes || ''
        });
      }
    }

    const sheet = XLSX.utils.json_to_sheet(rows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, sheet, 'Compatibility');
    downloadWorkbook(workbook, slug(metaProduct.name) + '-compatibility.xlsx');
  }

  // Parses an uploaded .xlsx File into normalized rows for a white/black list.
  // Expected columns: From Feature | From Option | To Feature | To Option | Notes
  function parseListFile(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target.result);
          const workbook = XLSX.read(data, { type: 'array' });
          const sheet = workbook.Sheets[workbook.SheetNames[0]];
          const rawRows = XLSX.utils.sheet_to_json(sheet, { defval: '' });

          const get = (row, key) => {
            const foundKey = Object.keys(row).find((k) => k.trim().toLowerCase() === key.toLowerCase());
            return foundKey ? row[foundKey] : '';
          };

          const rows = rawRows.map((row) => ({
            fromFeature: get(row, 'From Feature'),
            fromOption: get(row, 'From Option'),
            toFeature: get(row, 'To Feature'),
            toOption: get(row, 'To Option'),
            notes: get(row, 'Notes')
          }));
          resolve(rows);
        } catch (err) {
          reject(err);
        }
      };
      reader.onerror = reject;
      reader.readAsArrayBuffer(file);
    });
  }

  // Regenerates a downloadable .xlsx from a stored list's parsed rows.
  function downloadListFile(list) {
    const rows = (list.data || []).map((r) => ({
      'From Feature': r.fromFeature,
      'From Option': r.fromOption,
      'To Feature': r.toFeature,
      'To Option': r.toOption,
      Notes: r.notes || ''
    }));
    const sheet = XLSX.utils.json_to_sheet(rows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, sheet, list.type === 'whitelist' ? 'Whitelist' : 'Blacklist');
    downloadWorkbook(workbook, list.name + '.xlsx');
  }

  window.ExportXlsx = { downloadOptionsFile, downloadCompatibilityFile, parseListFile, downloadListFile };
})();
