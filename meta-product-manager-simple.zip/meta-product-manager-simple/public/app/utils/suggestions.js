// Heuristic "semi-auto populate" suggestion engine for Option Mapping.
(function () {
  const SUGGESTION_RULES = [
    { test: /colou?r/i, options: ['Black', 'White', 'Silver', 'Red', 'Blue', 'Green'] },
    { test: /size/i, options: ['Small', 'Medium', 'Large', 'X-Large'] },
    { test: /storage|capacity/i, options: ['64GB', '128GB', '256GB', '512GB', '1TB'] },
    { test: /memory|ram/i, options: ['4GB', '8GB', '16GB', '32GB'] },
    { test: /material/i, options: ['Plastic', 'Aluminum', 'Steel', 'Leather'] },
    { test: /warranty/i, options: ['1 Year', '2 Years', '3 Years', 'None'] },
    { test: /region|country/i, options: ['US', 'EU', 'UK', 'APAC'] }
  ];

  function suggestOptionsFor(feature) {
    if (feature.data_type === 'boolean') {
      return [
        { value: 'YES', label: 'Yes' },
        { value: 'NO', label: 'No' }
      ];
    }
    const rule = SUGGESTION_RULES.find((r) => r.test.test(feature.name));
    if (rule) {
      return rule.options.map((label) => ({
        value: label.toUpperCase().replace(/[^A-Z0-9]+/g, '_'),
        label
      }));
    }
    return [];
  }

  window.suggestOptionsFor = suggestOptionsFor;
})();
