// Plain API client — no bundler, no modules. Everything hangs off window.Api.
(function () {
  const BASE = '/api';

  async function request(path, options) {
    const res = await fetch(BASE + path, {
      headers: { 'Content-Type': 'application/json' },
      ...(options || {})
    });
    if (!res.ok) {
      let message = 'Request failed (' + res.status + ')';
      try {
        const body = await res.json();
        message = body.error || message;
      } catch (e) {
        /* ignore parse errors */
      }
      throw new Error(message);
    }
    if (res.status === 204) return null;
    return res.json();
  }

  window.Api = {
    // Meta Products
    listMetaProducts: (search) => request('/meta-products' + (search ? '?search=' + encodeURIComponent(search) : '')),
    getMetaProduct: (id) => request('/meta-products?id=' + id),
    createMetaProduct: (body) => request('/meta-products', { method: 'POST', body: JSON.stringify(body) }),
    updateMetaProduct: (id, body) => request('/meta-products?id=' + id, { method: 'PUT', body: JSON.stringify(body) }),
    deleteMetaProduct: (id) => request('/meta-products?id=' + id, { method: 'DELETE' }),

    // Features
    listFeatures: (metaProductId) => request('/features?meta_product_id=' + metaProductId),
    getFeature: (id) => request('/features?id=' + id),
    createFeature: (body) => request('/features', { method: 'POST', body: JSON.stringify(body) }),
    updateFeature: (id, body) => request('/features?id=' + id, { method: 'PUT', body: JSON.stringify(body) }),
    deleteFeature: (id) => request('/features?id=' + id, { method: 'DELETE' }),

    // Feature Options
    listFeatureOptions: (featureId) => request('/feature-options?feature_id=' + featureId),
    createFeatureOption: (body) => request('/feature-options', { method: 'POST', body: JSON.stringify(body) }),
    updateFeatureOption: (id, body) => request('/feature-options?id=' + id, { method: 'PUT', body: JSON.stringify(body) }),
    deleteFeatureOption: (id) => request('/feature-options?id=' + id, { method: 'DELETE' }),

    // Constraints
    listConstraints: (metaProductId, featureId, direction) => {
      let qs = '?meta_product_id=' + metaProductId;
      if (featureId) qs += '&feature_id=' + featureId;
      if (direction) qs += '&direction=' + direction;
      return request('/constraints' + qs);
    },
    createConstraint: (body) => request('/constraints', { method: 'POST', body: JSON.stringify(body) }),
    deleteConstraint: (id) => request('/constraints?id=' + id, { method: 'DELETE' }),

    // Constraint Lists (white/black list file uploads)
    listConstraintLists: (metaProductId) => request('/constraint-lists?meta_product_id=' + metaProductId),
    getConstraintListWithData: (id) => request('/constraint-lists?id=' + id + '&data=1'),
    uploadConstraintList: (body) => request('/constraint-lists', { method: 'POST', body: JSON.stringify(body) }),
    deleteConstraintList: (id) => request('/constraint-lists?id=' + id, { method: 'DELETE' })
  };
})();
