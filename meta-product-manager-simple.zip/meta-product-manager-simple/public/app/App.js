window.App = function App() {
  const route = Router.useHashRoute();

  let page;
  if (route.page === 'detail') {
    page = <window.Pages.MetaProductDetail id={route.id} tab={route.tab} query={route.query} />;
  } else {
    page = <window.Pages.MetaProductLookup />;
  }

  return (
    <div className="app-shell">
      <header className="app-header">
        <a href="#/" className="app-logo">
          Meta-Product Manager
        </a>
      </header>
      <main className="app-main">{page}</main>
    </div>
  );
};
