// Tiny hash-based router. No react-router-dom, no build step.
// Supported routes:
//   #/                                          -> meta-product lookup
//   #/meta-products/<id>/<tab>?<query string>   -> meta-product detail tabs
(function () {
  const { useState, useEffect, useCallback } = React;

  function parseHash(rawHash) {
    const hash = (rawHash || '').replace(/^#/, '');
    const [pathPart, queryPart] = hash.split('?');
    const segments = pathPart.split('/').filter(Boolean);
    const query = new URLSearchParams(queryPart || '');

    if (segments[0] === 'meta-products' && segments[1]) {
      return {
        page: 'detail',
        id: segments[1],
        tab: segments[2] || 'features',
        query
      };
    }
    return { page: 'lookup', query };
  }

  function navigate(path) {
    window.location.hash = path;
  }

  function useHashRoute() {
    const [route, setRoute] = useState(() => parseHash(window.location.hash));

    useEffect(() => {
      const onHashChange = () => setRoute(parseHash(window.location.hash));
      window.addEventListener('hashchange', onHashChange);
      return () => window.removeEventListener('hashchange', onHashChange);
    }, []);

    return route;
  }

  function useQueryParam(query, key, navigateBase) {
    const value = query.get(key) || '';
    const setValue = useCallback(
      (next) => {
        const params = new URLSearchParams(query);
        if (next) params.set(key, next);
        else params.delete(key);
        const qs = params.toString();
        navigate(navigateBase + (qs ? '?' + qs : ''));
      },
      [query, key, navigateBase]
    );
    return [value, setValue];
  }

  window.Router = { useHashRoute, navigate, useQueryParam };
})();
