-- ============================================================
-- Meta-Product Manager — Supabase schema
-- Run this in the Supabase SQL editor (or via `supabase db push`)
-- ============================================================

create extension if not exists "uuid-ossp";

-- ---------------------------------------------------------------
-- Meta Products
-- ---------------------------------------------------------------
create table if not exists meta_products (
  id            uuid primary key default uuid_generate_v4(),
  name          text not null,
  vendor        text,
  product_line  text,
  description   text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- ---------------------------------------------------------------
-- Features (belong to a meta product)
-- ---------------------------------------------------------------
create table if not exists features (
  id              uuid primary key default uuid_generate_v4(),
  meta_product_id uuid not null references meta_products(id) on delete cascade,
  name            text not null,
  description     text,
  data_type       text not null default 'choice', -- choice | boolean | number | text
  is_required     boolean not null default false,
  sort_order      integer not null default 0,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

create index if not exists idx_features_meta_product on features(meta_product_id);

-- ---------------------------------------------------------------
-- Feature Options / Choices (the selectable values of a feature)
-- ---------------------------------------------------------------
create table if not exists feature_options (
  id          uuid primary key default uuid_generate_v4(),
  feature_id  uuid not null references features(id) on delete cascade,
  value       text not null,        -- machine value / SKU code
  label       text not null,        -- human readable label
  sort_order  integer not null default 0,
  is_default  boolean not null default false,
  created_at  timestamptz not null default now()
);

create index if not exists idx_options_feature on feature_options(feature_id);

-- ---------------------------------------------------------------
-- Constraints (compatibility rules between two feature options)
--   type: 'whitelist' (option A requires/allows option B)
--         'blacklist' (option A excludes option B)
-- ---------------------------------------------------------------
create table if not exists constraints (
  id                uuid primary key default uuid_generate_v4(),
  meta_product_id   uuid not null references meta_products(id) on delete cascade,
  type              text not null check (type in ('whitelist','blacklist')),
  from_feature_id   uuid not null references features(id) on delete cascade,
  from_option_id    uuid references feature_options(id) on delete cascade,
  to_feature_id     uuid not null references features(id) on delete cascade,
  to_option_id      uuid references feature_options(id) on delete cascade,
  description       text,
  created_at        timestamptz not null default now()
);

create index if not exists idx_constraints_meta_product on constraints(meta_product_id);
create index if not exists idx_constraints_from_feature on constraints(from_feature_id);
create index if not exists idx_constraints_to_feature on constraints(to_feature_id);

-- ---------------------------------------------------------------
-- Constraint Lists (uploaded white/black list files, parsed to JSON)
-- ---------------------------------------------------------------
create table if not exists constraint_lists (
  id                uuid primary key default uuid_generate_v4(),
  meta_product_id   uuid not null references meta_products(id) on delete cascade,
  name              text not null,
  type              text not null check (type in ('whitelist','blacklist')),
  original_filename text,
  row_count         integer not null default 0,
  data              jsonb not null default '[]', -- parsed rows [{fromFeature,fromOption,toFeature,toOption}, ...]
  uploaded_at       timestamptz not null default now()
);

create index if not exists idx_lists_meta_product on constraint_lists(meta_product_id);

-- ---------------------------------------------------------------
-- updated_at triggers
-- ---------------------------------------------------------------
create or replace function set_updated_at() returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_meta_products_updated on meta_products;
create trigger trg_meta_products_updated before update on meta_products
  for each row execute procedure set_updated_at();

drop trigger if exists trg_features_updated on features;
create trigger trg_features_updated before update on features
  for each row execute procedure set_updated_at();
