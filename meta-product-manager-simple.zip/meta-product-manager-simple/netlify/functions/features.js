const { pgSelect, pgSelectOne, pgInsert, pgUpdate, pgDelete, json, handleError } = require('./_db.js');

// GET    /api/features?meta_product_id=<uuid>   -> list features (with options) for a meta product
// GET    /api/features?id=<uuid>                -> single feature (with options)
// POST   /api/features                          -> create { meta_product_id, name, description, data_type, is_required }
// PUT    /api/features?id=<uuid>                -> update feature details (optionally replace options[])
// DELETE /api/features?id=<uuid>                -> delete feature

exports.handler = async function (event) {
  const { id, meta_product_id } = event.queryStringParameters || {};

  try {
    switch (event.httpMethod) {
      case 'GET': {
        if (id) {
          const feature = await pgSelectOne('features', `id=eq.${id}`);
          const options = await pgSelect('feature_options', `feature_id=eq.${id}&order=sort_order.asc`);
          return json(200, { ...feature, options: options || [] });
        }

        if (!meta_product_id) {
          return json(400, { error: 'meta_product_id query param is required' });
        }

        const features = await pgSelect(
          'features',
          `meta_product_id=eq.${meta_product_id}&order=sort_order.asc`
        );
        const featureIds = (features || []).map((f) => f.id);

        let optionsByFeature = {};
        if (featureIds.length) {
          const idList = featureIds.join(',');
          const options = await pgSelect(
            'feature_options',
            `feature_id=in.(${idList})&order=sort_order.asc`
          );
          optionsByFeature = (options || []).reduce((acc, o) => {
            (acc[o.feature_id] ||= []).push(o);
            return acc;
          }, {});
        }

        const result = (features || []).map((f) => ({ ...f, options: optionsByFeature[f.id] || [] }));
        return json(200, result);
      }

      case 'POST': {
        const body = JSON.parse(event.body || '{}');
        if (!body.meta_product_id || !body.name) {
          return json(400, { error: 'meta_product_id and name are required' });
        }
        const [created] = await pgInsert('features', {
          meta_product_id: body.meta_product_id,
          name: body.name,
          description: body.description || null,
          data_type: body.data_type || 'choice',
          is_required: !!body.is_required,
          sort_order: body.sort_order ?? 0
        });
        return json(201, created);
      }

      case 'PUT': {
        if (!id) return json(400, { error: 'id query param is required' });
        const body = JSON.parse(event.body || '{}');

        const [updated] = await pgUpdate('features', `id=eq.${id}`, {
          name: body.name,
          description: body.description,
          data_type: body.data_type,
          is_required: body.is_required,
          sort_order: body.sort_order
        });

        if (Array.isArray(body.options)) {
          await pgDelete('feature_options', `feature_id=eq.${id}`);
          if (body.options.length) {
            const rows = body.options.map((o, idx) => ({
              feature_id: id,
              value: o.value,
              label: o.label,
              sort_order: o.sort_order ?? idx,
              is_default: !!o.is_default
            }));
            await pgInsert('feature_options', rows);
          }
        }

        return json(200, updated);
      }

      case 'DELETE': {
        if (!id) return json(400, { error: 'id query param is required' });
        await pgDelete('features', `id=eq.${id}`);
        return json(204, undefined);
      }

      default:
        return json(405, { error: 'Method not allowed' });
    }
  } catch (err) {
    return handleError(err);
  }
};
