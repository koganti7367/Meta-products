const { pgSelect, pgInsert, pgUpdate, pgDelete, json, handleError } = require('./_db.js');

// GET    /api/feature-options?feature_id=<uuid>  -> list options for a feature
// POST   /api/feature-options                    -> create { feature_id, value, label, is_default }
// PUT    /api/feature-options?id=<uuid>          -> update
// DELETE /api/feature-options?id=<uuid>          -> delete

exports.handler = async function (event) {
  const { id, feature_id } = event.queryStringParameters || {};

  try {
    switch (event.httpMethod) {
      case 'GET': {
        if (!feature_id) return json(400, { error: 'feature_id query param is required' });
        const data = await pgSelect('feature_options', `feature_id=eq.${feature_id}&order=sort_order.asc`);
        return json(200, data);
      }

      case 'POST': {
        const body = JSON.parse(event.body || '{}');
        if (!body.feature_id || !body.value || !body.label) {
          return json(400, { error: 'feature_id, value and label are required' });
        }
        const [created] = await pgInsert('feature_options', {
          feature_id: body.feature_id,
          value: body.value,
          label: body.label,
          sort_order: body.sort_order ?? 0,
          is_default: !!body.is_default
        });
        return json(201, created);
      }

      case 'PUT': {
        if (!id) return json(400, { error: 'id query param is required' });
        const body = JSON.parse(event.body || '{}');
        const [updated] = await pgUpdate('feature_options', `id=eq.${id}`, {
          value: body.value,
          label: body.label,
          sort_order: body.sort_order,
          is_default: body.is_default
        });
        return json(200, updated);
      }

      case 'DELETE': {
        if (!id) return json(400, { error: 'id query param is required' });
        await pgDelete('feature_options', `id=eq.${id}`);
        return json(204, undefined);
      }

      default:
        return json(405, { error: 'Method not allowed' });
    }
  } catch (err) {
    return handleError(err);
  }
};
