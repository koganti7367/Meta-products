const { pgSelect, pgSelectOne, pgInsert, pgDelete, json, handleError } = require('./_db.js');

// GET    /api/constraint-lists?meta_product_id=<uuid>   -> list uploaded files (metadata only)
// GET    /api/constraint-lists?id=<uuid>&data=1          -> single list including parsed rows
// POST   /api/constraint-lists -> {
//           meta_product_id, name, type ('whitelist'|'blacklist'),
//           original_filename, rows: [{ fromFeature, fromOption, toFeature, toOption, notes }, ...]
//         }
//         (the browser parses the .xlsx file with SheetJS and sends the rows as JSON —
//          no xlsx library needed server-side)
// DELETE /api/constraint-lists?id=<uuid>

const LIST_FIELDS = 'id,meta_product_id,name,type,original_filename,row_count,uploaded_at';

exports.handler = async function (event) {
  const { id, meta_product_id, data: includeData } = event.queryStringParameters || {};

  try {
    switch (event.httpMethod) {
      case 'GET': {
        if (id) {
          const fields = includeData ? '*' : LIST_FIELDS;
          const data = await pgSelectOne('constraint_lists', `id=eq.${id}&select=${fields}`);
          return json(200, data);
        }

        if (!meta_product_id) {
          return json(400, { error: 'meta_product_id query param is required' });
        }

        const data = await pgSelect(
          'constraint_lists',
          `meta_product_id=eq.${meta_product_id}&select=${LIST_FIELDS}&order=uploaded_at.desc`
        );
        return json(200, data);
      }

      case 'POST': {
        const body = JSON.parse(event.body || '{}');
        const required = ['meta_product_id', 'name', 'type', 'rows'];
        for (const field of required) {
          if (body[field] === undefined) return json(400, { error: `${field} is required` });
        }
        if (!['whitelist', 'blacklist'].includes(body.type)) {
          return json(400, { error: 'type must be "whitelist" or "blacklist"' });
        }
        if (!Array.isArray(body.rows)) {
          return json(400, { error: 'rows must be an array' });
        }

        const [created] = await pgInsert('constraint_lists', {
          meta_product_id: body.meta_product_id,
          name: body.name,
          type: body.type,
          original_filename: body.original_filename || null,
          row_count: body.rows.length,
          data: body.rows
        });

        const { data: _omit, ...meta } = created;
        return json(201, meta);
      }

      case 'DELETE': {
        if (!id) return json(400, { error: 'id query param is required' });
        await pgDelete('constraint_lists', `id=eq.${id}`);
        return json(204, undefined);
      }

      default:
        return json(405, { error: 'Method not allowed' });
    }
  } catch (err) {
    return handleError(err);
  }
};
