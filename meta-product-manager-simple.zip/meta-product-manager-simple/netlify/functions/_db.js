// Zero-dependency database access: talks straight to Supabase's built-in
// PostgREST API using the native `fetch` available in Netlify's Node runtime.
// No @supabase/supabase-js, no npm install required.

function baseUrl() {
  const url = process.env.SUPABASE_URL;
  if (!url) throw new Error('Missing SUPABASE_URL environment variable.');
  return `${url.replace(/\/$/, '')}/rest/v1`;
}

function authHeaders(extra = {}) {
  const key = process.env.SUPABASE_SERVICE_KEY;
  if (!key) throw new Error('Missing SUPABASE_SERVICE_KEY environment variable.');
  return {
    apikey: key,
    Authorization: `Bearer ${key}`,
    'Content-Type': 'application/json',
    ...extra
  };
}

// GET /<table>?<queryString>  -> always returns an array
async function pgSelect(table, queryString = '') {
  const res = await fetch(`${baseUrl()}/${table}${queryString ? `?${queryString}` : ''}`, {
    headers: authHeaders()
  });
  return handle(res);
}

// GET expecting exactly one row -> returns a single object (throws if 0 or many)
async function pgSelectOne(table, queryString = '') {
  const res = await fetch(`${baseUrl()}/${table}?${queryString}`, {
    headers: authHeaders({ Accept: 'application/vnd.pgrst.object+json' })
  });
  return handle(res);
}

// POST /<table>  body: object or array -> returns array of created rows
async function pgInsert(table, body) {
  const res = await fetch(`${baseUrl()}/${table}`, {
    method: 'POST',
    headers: authHeaders({ Prefer: 'return=representation' }),
    body: JSON.stringify(body)
  });
  return handle(res);
}

// PATCH /<table>?<queryString>  body: partial object -> returns array of updated rows
async function pgUpdate(table, queryString, body) {
  const res = await fetch(`${baseUrl()}/${table}?${queryString}`, {
    method: 'PATCH',
    headers: authHeaders({ Prefer: 'return=representation' }),
    body: JSON.stringify(body)
  });
  return handle(res);
}

// DELETE /<table>?<queryString>
async function pgDelete(table, queryString) {
  const res = await fetch(`${baseUrl()}/${table}?${queryString}`, {
    method: 'DELETE',
    headers: authHeaders()
  });
  if (!res.ok) await handle(res); // throws with details
  return true;
}

async function handle(res) {
  const text = await res.text();
  const data = text ? JSON.parse(text) : null;
  if (!res.ok) {
    const message = (data && (data.message || data.error || data.hint)) || `Request failed (${res.status})`;
    throw new Error(message);
  }
  return data;
}

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json' },
    body: body === undefined ? '' : JSON.stringify(body)
  };
}

function handleError(err) {
  console.error(err);
  return json(500, { error: err.message || 'Internal server error' });
}

module.exports = { pgSelect, pgSelectOne, pgInsert, pgUpdate, pgDelete, json, handleError };
