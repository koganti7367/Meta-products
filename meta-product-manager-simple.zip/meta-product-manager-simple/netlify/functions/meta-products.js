const { pgSelect, pgSelectOne, pgInsert, pgUpdate, pgDelete, json, handleError } = require('./_db.js');

// GET    /api/meta-products?search=xyz     -> list / search
// GET    /api/meta-products?id=<uuid>      -> single record
// POST   /api/meta-products                -> create { name, vendor, product_line, description }
// PUT    /api/meta-products?id=<uuid>      -> update
// DELETE /api/meta-products?id=<uuid>      -> delete

exports.handler = async function (event) {
  const { id, search } = event.queryStringParameters || {};

  try {
    switch (event.httpMethod) {
      case 'GET': {
        if (id) {
          const data = await pgSelectOne('meta_products', `id=eq.${id}`);
          return json(200, data);
        }
        let qs = 'order=updated_at.desc';
        if (search) {
          const term = encodeURIComponent(search.replace(/[*,()]/g, ''));
          qs += `&or=(name.ilike.*${term}*,vendor.ilike.*${term}*,product_line.ilike.*${term}*)`;
        }
        const data = await pgSelect('meta_products', qs);
        return json(200, data);
      }

      case 'POST': {
        const body = JSON.parse(event.body || '{}');
        if (!body.name) return json(400, { error: 'name is required' });
        const [created] = await pgInsert('meta_products', {
          name: body.name,
          vendor: body.vendor || null,
          product_line: body.product_line || null,
          description: body.description || null
        });
        return json(201, created);
      }

      case 'PUT': {
        if (!id) return json(400, { error: 'id query param is required' });
        const body = JSON.parse(event.body || '{}');
        const [updated] = await pgUpdate('meta_products', `id=eq.${id}`, {
          name: body.name,
          vendor: body.vendor,
          product_line: body.product_line,
          description: body.description
        });
        return json(200, updated);
      }

      case 'DELETE': {
        if (!id) return json(400, { error: 'id query param is required' });
        await pgDelete('meta_products', `id=eq.${id}`);
        return json(204, undefined);
      }

      default:
        return json(405, { error: 'Method not allowed' });
    }
  } catch (err) {
    return handleError(err);
  }
};
