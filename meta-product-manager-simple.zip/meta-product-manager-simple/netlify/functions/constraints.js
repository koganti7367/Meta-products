const { pgSelect, pgInsert, pgDelete, json, handleError } = require('./_db.js');

// GET    /api/constraints?meta_product_id=<uuid>
//          optional: &feature_id=<uuid>&direction=from|to|either  (default: either)
// POST   /api/constraints -> create { meta_product_id, type, from_feature_id, from_option_id,
//                                      to_feature_id, to_option_id, description }
// DELETE /api/constraints?id=<uuid>

const EMBED_SELECT =
  '*,from_feature:from_feature_id(id,name),from_option:from_option_id(id,value,label),' +
  'to_feature:to_feature_id(id,name),to_option:to_option_id(id,value,label)';

exports.handler = async function (event) {
  const { id, meta_product_id, feature_id, direction } = event.queryStringParameters || {};

  try {
    switch (event.httpMethod) {
      case 'GET': {
        if (!meta_product_id) {
          return json(400, { error: 'meta_product_id query param is required' });
        }

        let qs = `meta_product_id=eq.${meta_product_id}&select=${encodeURIComponent(EMBED_SELECT)}&order=created_at.desc`;

        if (feature_id) {
          const dir = direction || 'either';
          if (dir === 'from') qs += `&from_feature_id=eq.${feature_id}`;
          else if (dir === 'to') qs += `&to_feature_id=eq.${feature_id}`;
          else qs += `&or=(from_feature_id.eq.${feature_id},to_feature_id.eq.${feature_id})`;
        }

        const data = await pgSelect('constraints', qs);
        return json(200, data);
      }

      case 'POST': {
        const body = JSON.parse(event.body || '{}');
        const required = ['meta_product_id', 'type', 'from_feature_id', 'to_feature_id'];
        for (const field of required) {
          if (!body[field]) return json(400, { error: `${field} is required` });
        }
        if (!['whitelist', 'blacklist'].includes(body.type)) {
          return json(400, { error: 'type must be "whitelist" or "blacklist"' });
        }

        const [created] = await pgInsert('constraints', {
          meta_product_id: body.meta_product_id,
          type: body.type,
          from_feature_id: body.from_feature_id,
          from_option_id: body.from_option_id || null,
          to_feature_id: body.to_feature_id,
          to_option_id: body.to_option_id || null,
          description: body.description || null
        });

        // Re-fetch with embedded feature/option names for the UI
        const [withJoins] = await pgSelect(
          'constraints',
          `id=eq.${created.id}&select=${encodeURIComponent(EMBED_SELECT)}`
        );
        return json(201, withJoins || created);
      }

      case 'DELETE': {
        if (!id) return json(400, { error: 'id query param is required' });
        await pgDelete('constraints', `id=eq.${id}`);
        return json(204, undefined);
      }

      default:
        return json(405, { error: 'Method not allowed' });
    }
  } catch (err) {
    return handleError(err);
  }
};
